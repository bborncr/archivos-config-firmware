The following files are daily firmware for ESP32-based boards without external SPIRAM.

This firmware is compiled using ESP-IDF v4.x.
