#define MICROPY_HW_BOARD_NAME "CRCibernetica IdeaBoard"
#define MICROPY_HW_MCU_NAME "ESP32"
